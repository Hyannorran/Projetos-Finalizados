package com.ProjetoFinal.goldestile.HomeController;

// ./mvnw clean para limpar
// ./mvnw spring-boot:run para rodar

import com.ProjetoFinal.goldestile.model.Admin;
import com.ProjetoFinal.goldestile.model.Camisa;
import com.ProjetoFinal.goldestile.model.Cliente;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
public class HomeController{
    static List<Cliente> clientesList = new ArrayList<>();
    static List<Admin> AdminsList = new ArrayList<>();
    static List<Camisa> camisasList = new ArrayList<>();

    //clientesList.add(new Cliente());
    //clientesList.add(new Cliente());

    //AdminsList.add(new Admin());

    //camisasList.add(new Camisa());
    //camisasList.add(new Camisa());
    //camisasList.add(new Camisa());



    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("mensagem", "Bem-vindo ao Spring com Thymeleaf!");
        return "index";
    }
}
