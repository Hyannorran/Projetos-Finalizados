package com.ProjetoFinal.goldestile.model;

public class Cliente {
    private String nome;
    private int CPF;
    private String email;
    private String senha;

    public Cliente(String nome, int CPF, String email, String senha) {
        this.nome = nome;
        this.CPF = CPF;
        this.email = email;
        this.senha = senha;
    }


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCPF() {
        return CPF;
    }

    public void setCPF(int CPF) {
        this.CPF = CPF;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}
