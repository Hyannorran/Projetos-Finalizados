package com.ProjetoFinal.goldestile.model;

public class Camisa {
    private int ID;
    private String descricao;
    private String nome;
    private int quantidade;
    private int valor;
    private int ID_Admin_FK;


    public Camisa(int ID, String descricao, String nome, int quantidade, int valor) {
        this.ID = ID;
        this.descricao = descricao;
        this.nome = nome;
        this.quantidade = quantidade;
        this.valor = valor;
    }

    public Camisa(int ID, String descricao, String nome, int quantidade, int valor, int ID_Admin_FK) {
        this.ID = ID;
        this.descricao = descricao;
        this.nome = nome;
        this.quantidade = quantidade;
        this.valor = valor;
        this.ID_Admin_FK = ID_Admin_FK;
    }

    public int getID_Admin_FK() {
        return ID_Admin_FK;
    }

    public void setID_Admin_FK(int ID_Admin_FK) {
        this.ID_Admin_FK = ID_Admin_FK;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        descricao = descricao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        quantidade = quantidade;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }
}
